/**
 * GitHub OAuth Configuration for LeetCode Tracker.
 *
 * To set up your own credentials:
 * 1. Go to https://github.com/settings/developers
 * 2. Click "New OAuth App"
 * 3. Set "Application name" to "LeetCode Tracker"
 * 4. Set "Homepage URL" to "https://leetcode.com"
 * 5. Set "Authorization callback URL" to "https://github.com/"
 * 6. Click "Register application"
 * 7. Copy your Client ID and generate a Client Secret
 * 8. Replace the placeholder values below
 */
export const ENV = {
  URL: "https://github.com/login/oauth/authorize",
  ACCESS_TOKEN_URL: "https://github.com/login/oauth/access_token",
  REDIRECT_URL: "https://github.com/",
  REPOSITORY_URL: "https://api.github.com/repos/",
  USER_INFO_URL: "https://api.github.com/user",
  CLIENT_SECRET: "YOUR_CLIENT_SECRET_KEY",
  CLIENT_ID: "YOUR_CLIENT_ID",
  SCOPES: ["repo"],
  HEADERS: {
    Accept: "application/json",
    "Content-Type": "application/json",
  },
};
